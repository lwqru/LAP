package sa.edu.iau.cshj.studyplanner.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import sa.edu.iau.cshj.studyplanner.ui.theme.StudyPlannerTheme

data class PlannerUiState(
    val greeting: String = "Welcome to your Study Planner!",
    val tasks: List<String> = listOf(
        "Complete CSC 402 Lab 5",
        "Review Kotlin Notes",
        "Prepare for Quiz"
    ),
    val doneCount: Int = 0
)

@Composable
fun PlannerHomeScreen(
    uiState: PlannerUiState,
    onTaskClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(uiState.greeting, style = MaterialTheme.typography.headlineSmall)
        Text(
            "Study progress: ${uiState.doneCount} of ${uiState.tasks.size} done",
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text("My Study Tasks", style = MaterialTheme.typography.titleLarge)

        uiState.tasks.forEach { task ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { onTaskClick(task) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(task)
                }
            }
        }
    }
}

@Composable
fun PlannerHomeRoute(onTaskClick: (String) -> Unit) {
    var uiState by remember { mutableStateOf(PlannerUiState()) }

    PlannerHomeScreen(
        uiState = uiState,
        onTaskClick = onTaskClick
    )
}

@Preview(showBackground = true, name = "Study tasks - none done")
@Composable
private fun PlannerHomePreviewEmpty() {
    StudyPlannerTheme {
        PlannerHomeScreen(
            uiState = PlannerUiState(doneCount = 0),
            onTaskClick = {}
        )
    }
}

@Preview(showBackground = true, name = "Study tasks - progress")
@Composable
private fun PlannerHomePreviewProgress() {
    StudyPlannerTheme {
        PlannerHomeScreen(
            uiState = PlannerUiState(doneCount = 2),
            onTaskClick = {}
        )
    }
}
