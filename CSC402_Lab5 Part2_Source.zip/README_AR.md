# CSC 402 – Lab 5 Individual Assignment
## StudyPlanner – Part 2

هذه ملفات المصدر المطلوبة لإضافة الجزء الثاني إلى مشروع StudyPlanner الذي بدأ في Lab 4.

### الملفات
- `MainActivity.kt`: نقطة تشغيل التطبيق.
- `ui/PlannerHomeScreen.kt`: الشاشة الرئيسية وقائمة المهام ومعاينتان للشاشة الرئيسية.
- `ui/TaskDetailScreen.kt`: حالة شاشة التفاصيل، الشاشة، Route، ومعاينتان.
- `navigation/Routes.kt`: مسارات التنقل.
- `navigation/StudyPlannerApp.kt`: ربط الشاشات باستخدام NavHost.

> ملاحظة: ملف Lab 4 المرفوع هو ورقة تعليمات وليس ملفات Kotlin الأصلية. لذلك هذه نسخة مكتملة متوافقة مع متطلبات Part 1 وPart 2، وقد تحتاجين إلى تعديل اسم الـ Theme أو دمجها مع ملفاتك الموجودة بدل استبدال المشروع كله.

## 1. إعداد Gradle
في `app/build.gradle.kts` أضيفي plugin الخاص بـ Kotlin Serialization داخل `plugins`، مع استخدام **نفس إصدار Kotlin الموجود في مشروعك**:

```kotlin
plugins {
    // أبقي الإضافات الموجودة
    id("org.jetbrains.kotlin.plugin.serialization") version "<SAME_KOTLIN_VERSION>"
}
```

وفي `dependencies` أضيفي:

```kotlin
implementation("androidx.navigation:navigation-compose:2.10.2")
implementation("org.jetbrains.kotlinx:kotlinx-serialization-core:1.9.0")
```

إذا كان مشروعك يستخدم Version Catalog (`libs.versions.toml`)، تقدرين تضيفين plugin بالطريقة المستخدمة في مشروعك، بشرط أن يتطابق إصداره مع Kotlin. بعد ذلك اضغطي **Sync Now**.

## 2. أين توضع الملفات؟
داخل `app/src/main/java/sa/edu/iau/cshj/studyplanner/`:
- ضعي `MainActivity.kt` في المجلد الأساسي.
- أنشئي package باسم `navigation` وضعي فيه ملفي Routes وStudyPlannerApp.
- أنشئي package باسم `ui` وضعي فيه ملفي الشاشات.

إذا كان اسم الـ Theme في مشروعك ليس `StudyPlannerTheme`، غيّريه في `MainActivity.kt` ومعاينات Preview إلى اسم الـ Theme الفعلي.

## 3. الرسم الورقي المطلوب (P2.1)
ارسمي مربعًا للشاشة الرئيسية يحتوي على عنوان Study Planner وثلاثة أزرار مهام:
- Complete CSC 402 Lab 5
- Review Kotlin Notes
- Prepare for Quiz

ارسمي سهمًا من كل مهمة إلى شاشة Task Details التي تعرض عنوان المهمة وزري Share وBack. ارسمي سهم الرجوع من التفاصيل إلى Home. اكتبي بجانب الرسم:
- Detail screen needs: task title.
- User actions: select a task, share task title, go back.

صوّري الرسم الورقي بنفسك؛ لا يُستبدل بصورة مولّدة إذا كان المطلوب صورة الرسم الذي أعددتيه.

## 4. لقطات الشاشة المطلوبة
1. الشاشة الرئيسية وفيها المهام الثلاث.
2. شاشة تفاصيل إحدى المهام.
3. نافذة Share sheet مفتوحة بعد الضغط على Share.
4. Preview الأولى لشاشة التفاصيل.
5. Preview الثانية لشاشة التفاصيل.

## 5. فحص قبل التسليم
- شغّلي التطبيق على Emulator أو جهاز فعلي.
- اضغطي على كل مهمة وتحققي أن العنوان الصحيح يظهر في شاشة التفاصيل.
- جرّبي Share وBack.
- حدّثي AI Use & Disclosure Log بصدق. مثال مقترح: “Used ChatGPT to help draft and review the Lab 5 navigation and sharing implementation; reviewed and adapted the code and tested it in Android Studio.” عدّلي الوصف ليطابق ما فعلتيه فعلًا.
